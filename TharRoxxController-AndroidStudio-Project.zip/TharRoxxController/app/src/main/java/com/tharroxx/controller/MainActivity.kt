package com.tharroxx.controller

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val mainHandler = Handler(Looper.getMainLooper())
    private var adapter: BluetoothAdapter? = null
    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var output: OutputStream? = null
    @Volatile private var connected = false

    private lateinit var statusText: TextView
    private lateinit var distanceText: TextView
    private lateinit var warningText: TextView
    private lateinit var connectButton: Button
    private lateinit var gearText: TextView
    private lateinit var gearButtons: MutableList<Button>
    private var selectedGear = 1
    private var headlightsOn = false
    private var interiorOn = false

    private val amber = Color.rgb(245, 158, 11)
    private val panel = Color.rgb(37, 42, 51)
    private val text = Color.WHITE
    private val muted = Color.rgb(174, 183, 196)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        adapter = BluetoothAdapter.getDefaultAdapter()
        buildUi()
        ensureBluetoothPermission()
    }

    private fun ensureBluetoothPermission() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 100)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            refreshConnectionLabel()
        } else if (requestCode == 100) {
            toast("Bluetooth permission is required to connect to HC-05.")
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(17, 19, 24))
            setPadding(dp(16), dp(18), dp(16), dp(18))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        content.addView(label("THAR ROXX", 28, text, true))
        content.addView(label("4WD BLUETOOTH CONTROL", 12, muted, true).apply {
            setPadding(0, 0, 0, dp(14))
        })

        connectButton = button("CONNECT HC-05", amber).apply {
            setOnClickListener { chooseBluetoothDevice() }
        }
        content.addView(connectButton, matchWrap())
        statusText = label("● DISCONNECTED", 14, Color.rgb(248, 113, 113), true)
        statusText.setPadding(0, dp(10), 0, dp(14))
        content.addView(statusText)

        content.addView(section("GEAR SELECTOR"))
        gearText = label("GEAR 1  •  LOW SPEED", 20, amber, true)
        content.addView(gearText)
        val gearRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        gearButtons = mutableListOf()
        for (g in 1..5) {
            val b = button("$g", if (g == 1) amber else panel).apply {
                setOnClickListener {
                    selectedGear = g
                    send(g.toString())
                    updateGearUi()
                }
            }
            gearButtons.add(b)
            val lp = LinearLayout.LayoutParams(0, dp(52), 1f)
            lp.setMargins(dp(3), dp(5), dp(3), dp(10))
            gearRow.addView(b, lp)
        }
        content.addView(gearRow)

        content.addView(section("DRIVING"))
        val pad = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        pad.addView(directionButton("▲", "F"), LinearLayout.LayoutParams(dp(82), dp(60)))
        val middle = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        middle.addView(directionButton("◀", "L"), LinearLayout.LayoutParams(dp(82), dp(60)))
        middle.addView(button("BRAKE", Color.rgb(180, 35, 24)).apply {
            setOnClickListener { send("S") }
        }, LinearLayout.LayoutParams(dp(100), dp(60)).apply { setMargins(dp(8), 0, dp(8), 0) })
        middle.addView(directionButton("▶", "R"), LinearLayout.LayoutParams(dp(82), dp(60)))
        pad.addView(middle)
        pad.addView(directionButton("▼", "B"), LinearLayout.LayoutParams(dp(82), dp(60)))
        content.addView(pad)

        content.addView(section("LIGHTING"))
        val lights = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        lights.addView(button("HEADLIGHT: OFF", panel).apply {
            setOnClickListener {
                headlightsOn = !headlightsOn
                send("H")
                text = if (headlightsOn) "HEADLIGHT: ON" else "HEADLIGHT: OFF"
            }
        }, LinearLayout.LayoutParams(0, dp(54), 1f).apply { setMargins(0, 0, dp(5), 0) })
        lights.addView(button("INTERIOR: OFF", panel).apply {
            setOnClickListener {
                interiorOn = !interiorOn
                send("I")
                text = if (interiorOn) "INTERIOR: ON" else "INTERIOR: OFF"
            }
        }, LinearLayout.LayoutParams(0, dp(54), 1f).apply { setMargins(dp(5), 0, 0, 0) })
        content.addView(lights)

        content.addView(section("REVERSE PARKING ASSIST"))
        distanceText = label("-- cm", 30, Color.rgb(34, 197, 94), true)
        content.addView(distanceText)
        warningText = label("Waiting for sensor data", 14, muted, false)
        content.addView(warningText.apply { setPadding(0, dp(4), 0, dp(12)) })

        content.addView(label(
            "Safety: test with wheels lifted first. Stop the car manually if the sensor reading is missing or unreliable.",
            12, muted, false
        ).apply { setPadding(0, dp(12), 0, dp(8)) })

        setContentView(root)
        updateGearUi()
        refreshConnectionLabel()
    }

    private fun directionButton(caption: String, command: String): Button {
        return button(caption, panel).apply {
            setOnTouchListener { v, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        v.isPressed = true
                        send(command)
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        v.isPressed = false
                        send("S")
                        true
                    }
                    else -> true
                }
            }
        }
    }

    private fun chooseBluetoothDevice() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            ensureBluetoothPermission()
            return
        }
        val bt = adapter
        if (bt == null) {
            toast("This phone does not support Bluetooth.")
            return
        }
        if (!bt.isEnabled) {
            toast("Turn on Bluetooth in Android settings, then reconnect.")
            return
        }
        val devices = try { bt.bondedDevices?.toList().orEmpty() } catch (_: SecurityException) { emptyList() }
        if (devices.isEmpty()) {
            toast("Pair HC-05 in Android Bluetooth settings first (often PIN 1234 or 0000).")
            return
        }
        val names = devices.map { "${it.name ?: "Unknown"}\n${it.address}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Select paired Bluetooth device")
            .setItems(names) { _, which -> connect(devices[which]) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun connect(device: BluetoothDevice) {
        disconnect()
        status("● CONNECTING…", amber)
        thread {
            try {
                val s = device.createRfcommSocketToServiceRecord(sppUuid)
                s.connect()
                socket = s
                output = s.outputStream
                connected = true
                mainHandler.post {
                    connectButton.text = "DISCONNECT"
                    connectButton.setOnClickListener {
                        disconnect()
                        refreshConnectionLabel()
                    }
                    status("● CONNECTED: ${device.name ?: "HC-05"}", Color.rgb(34, 197, 94))
                    toast("Bluetooth connected")
                }
                listenForData(s)
            } catch (e: Exception) {
                disconnect()
                mainHandler.post {
                    status("● CONNECTION FAILED", Color.rgb(248, 113, 113))
                    connectButton.text = "CONNECT HC-05"
                    connectButton.setOnClickListener { chooseBluetoothDevice() }
                    toast("Could not connect. Check pairing and HC-05 power.")
                }
            }
        }
    }

    private fun listenForData(s: BluetoothSocket) {
        try {
            val reader = BufferedReader(InputStreamReader(s.inputStream))
            while (connected) {
                val line = reader.readLine() ?: break
                mainHandler.post { handleIncoming(line.trim()) }
            }
        } catch (_: Exception) {
            // Disconnect is reflected below.
        } finally {
            if (connected) {
                disconnect()
                mainHandler.post { refreshConnectionLabel() }
            }
        }
    }

    private fun handleIncoming(line: String) {
        if (line.startsWith("DIST:", ignoreCase = true)) {
            val value = line.substringAfter(":").substringBefore(" ").toIntOrNull()
            if (value != null) {
                distanceText.text = "$value cm"
                when {
                    value <= 15 -> {
                        distanceText.setTextColor(Color.rgb(248, 113, 113))
                        warningText.text = "OBSTACLE VERY CLOSE — STOP"
                        warningText.setTextColor(Color.rgb(248, 113, 113))
                    }
                    value <= 30 -> {
                        distanceText.setTextColor(amber)
                        warningText.text = "CAUTION — OBSTACLE NEARBY"
                        warningText.setTextColor(amber)
                    }
                    else -> {
                        distanceText.setTextColor(Color.rgb(34, 197, 94))
                        warningText.text = "CLEAR"
                        warningText.setTextColor(Color.rgb(34, 197, 94))
                    }
                }
            } else {
                distanceText.text = "-- cm"
                warningText.text = "Sensor out of range"
            }
        } else if (line.contains("OUT OF RANGE", true)) {
            distanceText.text = "-- cm"
            warningText.text = "Sensor out of range"
        } else if (line.contains("OBSTACLE WARNING", true)) {
            warningText.text = "OBSTACLE WARNING — CAR STOPPED"
            warningText.setTextColor(Color.rgb(248, 113, 113))
        }
    }

    private fun send(command: String) {
        val stream = output
        if (!connected || stream == null) {
            toastOnce()
            return
        }
        thread {
            try {
                synchronized(this) {
                    stream.write(command.toByteArray(Charsets.US_ASCII))
                    stream.flush()
                }
            } catch (_: Exception) {
                mainHandler.post {
                    disconnect()
                    refreshConnectionLabel()
                }
            }
        }
    }

    private var lastToastAt = 0L
    private fun toastOnce() {
        val now = System.currentTimeMillis()
        if (now - lastToastAt > 2500) {
            lastToastAt = now
            toast("Connect to HC-05 before driving.")
        }
    }

    private fun disconnect() {
        connected = false
        try { output?.close() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        output = null
        socket = null
    }

    private fun refreshConnectionLabel() {
        connectButton.text = "CONNECT HC-05"
        connectButton.setOnClickListener { chooseBluetoothDevice() }
        status("● DISCONNECTED", Color.rgb(248, 113, 113))
    }

    private fun updateGearUi() {
        val labels = arrayOf("", "LOW SPEED", "CRAWL", "NORMAL", "FAST", "MAX SPEED")
        gearText.text = "GEAR $selectedGear  •  ${labels[selectedGear]}"
        gearButtons.forEachIndexed { index, b ->
            b.setBackgroundColor(if (index + 1 == selectedGear) amber else panel)
            b.setTextColor(text)
        }
    }

    private fun status(value: String, color: Int) {
        if (::statusText.isInitialized) {
            statusText.text = value
            statusText.setTextColor(color)
        }
    }

    private fun section(value: String): TextView =
        label(value, 13, amber, true).apply {
            gravity = Gravity.START
            setPadding(0, dp(18), 0, dp(8))
        }

    private fun label(value: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun button(value: String, color: Int): Button =
        Button(this).apply {
            text = value
            textSize = 13f
            setTextColor(Color.WHITE)
            setBackgroundColor(color)
            isAllCaps = false
        }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, dp(52))
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun toast(value: String) = Toast.makeText(this, value, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        disconnect()
        super.onDestroy()
    }
}
